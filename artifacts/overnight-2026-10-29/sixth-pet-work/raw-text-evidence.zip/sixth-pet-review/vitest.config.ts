import { resolve } from 'node:path'
import { defineConfig } from 'vitest/config'
export default defineConfig({ resolve: { alias: { '@shared': resolve('src/shared') } }, test: { include: ['previews/overnight-2026-10-29/sixth-pet-review/*.test.ts'] } })
