import { createHash } from 'node:crypto'
import { readdirSync, readFileSync, statSync, writeFileSync } from 'node:fs'
import { join, relative, resolve } from 'node:path'
import { extractFile } from '@electron/asar'
import assert from 'node:assert/strict'
const root=process.cwd(), output=resolve('release/continuous-2026-10-29-autonomy-sync'), resources=join(output,'win-unpacked/resources'), archive=join(resources,'app.asar')
const hash=bytes=>createHash('sha256').update(bytes).digest('hex')
const walk=dir=>readdirSync(dir,{withFileTypes:true}).flatMap(item=>item.isDirectory()?walk(join(dir,item.name)):[join(dir,item.name)])
const code=['main','preload','renderer'].flatMap(folder=>walk(join(root,'out',folder))).map(file=>{const path=relative(root,file);const actual=hash(extractFile(archive,path));assert.equal(actual,hash(readFileSync(file)),path);return {path:path.replaceAll('\\','/'),sha256:actual}})
const compareTree=(source,target)=>walk(source).filter(file=>!relative(source,file).startsWith('.')).map(file=>{const path=relative(source,file),actual=hash(readFileSync(join(target,path)));assert.equal(actual,hash(readFileSync(file)),path);return {path:path.replaceAll('\\','/'),sha256:actual}})
const models=compareTree(join(root,'build/bundled-models'),join(resources,'models'));assert.equal(models.length,18)
const isolation=compareTree(join(root,'isolation'),join(resources,'isolation'))
const currentInstaller=join(output,'Murasame-Setup-0.9.0.exe')
const previousInstaller=join(root,'release/overnight-2026-10-29-sixth-delivery/Murasame-Setup-0.9.0.exe')
assert.equal(hash(readFileSync(previousInstaller)),'4cf9487c442b62ca24c562610e15387d37b843cf0a93caa1dd0214effb8fd6bd')
const receipt={at:new Date().toISOString(),output,asarSha256:hash(readFileSync(archive)),installer:{path:currentInstaller,bytes:statSync(currentInstaller).size,sha256:hash(readFileSync(currentInstaller))},previousInstallerUnchanged:true,code,models,isolation,sourceSha256:hash(readFileSync('src/renderer/src/pages/AutonomyPage.tsx'))}
writeFileSync('previews/continuous-24h-2026-10-29/autonomy-page/package-receipt.json',JSON.stringify(receipt,null,2)+'\n')
console.log(JSON.stringify({installer:receipt.installer,codeFiles:code.length,models:models.length,isolation:isolation.length,previousInstallerUnchanged:true},null,2))
