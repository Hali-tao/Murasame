﻿Unicode true
RequestExecutionLevel user
Name "Murasame isolated uninstall test"
OutFile "fixture.exe"
AutoCloseWindow true
ShowInstDetails nevershow
!include "LogicLib.nsh"
!include "E:/Desktop/软件工程/murasame/node_modules/app-builder-lib/templates/nsis/include/StdUtils.nsh"
!addplugindir "C:/Users/LENOVO/AppData/Local/electron-builder/Cache/nsis/resources-3.4.1/plugins/x86-unicode"
!macro _isUpdated _a _b _t _f
  ${StdUtils.TestParameter} $R9 "updated"
  StrCmp "$R9" "true" `${_t}` `${_f}`
!macroend
!define isUpdated `"" isUpdated ""`
!include "hook.nsh"
Page instfiles
Section
  !insertmacro customUnInstall
  FileOpen $0 "$EXEDIR\completed.txt" w
  FileWrite $0 "hook returned"
  FileClose $0
SectionEnd