import { createHash } from 'node:crypto'
import { readdirSync, readFileSync, statSync, writeFileSync } from 'node:fs'
import { join, relative, resolve } from 'node:path'
import assert from 'node:assert/strict'
import { extractFile } from '@electron/asar'

const output = resolve('release/continuous-2026-10-29-uninstall-policy')
const base = 'previews/uninstall-policy-2026-10-29'
const previous = JSON.parse(readFileSync('previews/coworker-issues-2026-10-29/package-receipt.json', 'utf8'))
const hash = bytes => createHash('sha256').update(bytes).digest('hex')
const archive = join(output, 'win-unpacked/resources/app.asar')
const walk = dir => readdirSync(dir, { withFileTypes: true }).flatMap(item => item.isDirectory() ? walk(join(dir, item.name)) : [join(dir, item.name)])
const program = ['main', 'preload', 'renderer'].flatMap(folder => walk(join('out', folder))).map(file => {
  const path = file.replaceAll('\\', '/')
  const sha256 = hash(extractFile(archive, file))
  assert.equal(sha256, hash(readFileSync(file)), path)
  const prior = previous.code.find(item => item.path === path)
  assert.ok(prior, `Unexpected program resource ${path}`)
  assert.equal(sha256, prior.sha256, `Application resource changed: ${path}`)
  return { path, sha256 }
})
assert.equal(program.length, previous.code.length)
const compare = (source, destination, expected) => {
  const files = walk(source).filter(file => !relative(source, file).startsWith('.')).map(file => {
    const path = relative(source, file).replaceAll('\\', '/')
    const sha256 = hash(readFileSync(join(destination, path)))
    assert.equal(sha256, hash(readFileSync(file)), path)
    assert.equal(sha256, expected.find(item => item.path === path)?.sha256, path)
    return { path, sha256 }
  })
  assert.equal(files.length, expected.length)
  return files
}
const resources = join(output, 'win-unpacked/resources')
const models = compare('build/bundled-models', join(resources, 'models'), previous.models)
const isolation = compare('isolation', join(resources, 'isolation'), previous.isolation)
const previousInstallers = [...previous.previousInstallers, previous.installer].map(({ path, sha256 }) => {
  assert.equal(hash(readFileSync(path)), sha256, path)
  return { path, sha256, unchanged: true }
})
const installerPath = join(output, 'Murasame-Setup-0.9.0.exe')
const sources = ['build/installer.nsh', 'scripts/verify-uninstall-hook.mjs', 'tests/unit/uninstall-policy-native.test.ts']
const receipt = {
  at: new Date().toISOString(), baseline: '7aa598856709f91d6fa327f4cbb94dc7192d9a5d', output,
  installer: { path: installerPath, bytes: statSync(installerPath).size, sha256: hash(readFileSync(installerPath)) },
  asarSha256: hash(readFileSync(archive)), program, models, isolation, previousInstallers,
  applicationResourcesUnchangedFromPreviousDelivery: true,
  sourceFiles: sources.map(path => ({ path, sha256: hash(readFileSync(path)), textLfSha256: hash(readFileSync(path, 'utf8').replaceAll('\r\n', '\n')) }))
}
writeFileSync(join(base, 'package-receipt.json'), JSON.stringify(receipt, null, 2) + '\n')
console.log(JSON.stringify({ installer: receipt.installer, applicationFiles: program.length, models: models.length, isolation: isolation.length, previousInstallers: previousInstallers.length }, null, 2))
