import { createHash } from 'node:crypto'
import { readdirSync, readFileSync, statSync, writeFileSync } from 'node:fs'
import { join, relative, resolve } from 'node:path'
import assert from 'node:assert/strict'
import { extractFile } from '@electron/asar'
const base = 'previews/memory-degraded-context-2026-10-29'
const output = resolve('release/continuous-2026-10-29-memory-degraded-context')
const previous = JSON.parse(readFileSync('previews/uninstall-policy-2026-10-29/package-receipt.json', 'utf8'))
const hash = bytes => createHash('sha256').update(bytes).digest('hex')
const archive = join(output, 'win-unpacked/resources/app.asar')
const walk = dir => readdirSync(dir, { withFileTypes: true }).flatMap(item => item.isDirectory() ? walk(join(dir, item.name)) : [join(dir, item.name)])
const code = ['main', 'preload', 'renderer'].flatMap(folder => walk(join('out', folder))).map(file => {
  const sha256 = hash(extractFile(archive, file))
  assert.equal(sha256, hash(readFileSync(file)), file)
  return { path: file.replaceAll('\\', '/'), sha256 }
})
assert.equal(code.length, previous.program.length)
const changedProgramFiles = code.filter(file => previous.program.find(item => item.path === file.path)?.sha256 !== file.sha256).map(file => file.path)
assert.deepEqual(changedProgramFiles, ['out/main/index.js'])
const compare = (source, destination, expected) => {
  const files = walk(source).filter(file => !relative(source, file).startsWith('.')).map(file => {
    const path = relative(source, file).replaceAll('\\', '/')
    const sha256 = hash(readFileSync(join(destination, path)))
    assert.equal(sha256, hash(readFileSync(file)), path)
    assert.equal(sha256, expected.find(item => item.path === path)?.sha256, path)
    return { path, sha256 }
  })
  assert.equal(files.length, expected.length)
  return files
}
const resources = join(output, 'win-unpacked/resources')
const models = compare('build/bundled-models', join(resources, 'models'), previous.models)
const isolation = compare('isolation', join(resources, 'isolation'), previous.isolation)
const previousInstallers = [...previous.previousInstallers, previous.installer].map(({ path, sha256 }) => {
  assert.equal(hash(readFileSync(path)), sha256, path)
  return { path, sha256, unchanged: true }
})
const installerPath = join(output, 'Murasame-Setup-0.9.0.exe')
const sources = ['src/main/core/services/memory-service.ts', 'src/main/core/services/conversation-service.ts', 'tests/unit/conversation-memory-maturity.test.ts', 'tests/e2e/memory-degraded-context.spec.ts', 'tests/e2e/local-memory.spec.ts', 'build/installer.nsh']
const receipt = {
  at: new Date().toISOString(), baseline: 'c8590aa8529d8e24023264c1218df694ab7b4ea7', output,
  installer: { path: installerPath, bytes: statSync(installerPath).size, sha256: hash(readFileSync(installerPath)) },
  asarSha256: hash(readFileSync(archive)), code, changedProgramFiles, models, isolation, previousInstallers,
  sourceFiles: sources.map(path => ({ path, sha256: hash(readFileSync(path)), textLfSha256: hash(readFileSync(path, 'utf8').replaceAll('\r\n', '\n')) }))
}
writeFileSync(join(base, 'package-receipt.json'), JSON.stringify(receipt, null, 2) + '\n')
console.log(JSON.stringify({ installer: receipt.installer, applicationFiles: code.length, changedProgramFiles, models: models.length, isolation: isolation.length, previousInstallers: previousInstallers.length }, null, 2))
