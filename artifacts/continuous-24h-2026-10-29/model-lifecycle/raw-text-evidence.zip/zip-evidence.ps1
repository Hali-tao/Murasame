$ErrorActionPreference = 'Stop'
$evidenceRoot = (Resolve-Path 'previews/continuous-24h-2026-10-29/model-lifecycle').Path
$archivePath = Join-Path $evidenceRoot 'raw-text-evidence.zip'
if (Test-Path -LiteralPath $archivePath) { throw 'Raw archive already exists; preserve it.' }
Add-Type -AssemblyName System.IO.Compression
$files = Get-ChildItem -LiteralPath $evidenceRoot -File -Recurse | Where-Object {
  $_.Extension -in @('.txt', '.md', '.json', '.mjs', '.ps1') -and $_.FullName -notlike '*\.playwright-artifacts*'
}
$archive = [System.IO.Compression.ZipFile]::Open($archivePath, [System.IO.Compression.ZipArchiveMode]::Create)
try {
  foreach ($file in $files) {
    $entry = [System.IO.Path]::GetRelativePath($evidenceRoot, $file.FullName).Replace('\', '/')
    [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive, $file.FullName, $entry) | Out-Null
  }
} finally { $archive.Dispose() }
Write-Output "Raw text files preserved: $($files.Count)"
