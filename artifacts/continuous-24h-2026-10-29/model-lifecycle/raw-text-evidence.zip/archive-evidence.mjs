import { mkdirSync, readFileSync, readdirSync, writeFileSync, copyFileSync, existsSync } from 'node:fs'
import { join, relative, resolve, extname } from 'node:path'
import { createHash } from 'node:crypto'
import assert from 'node:assert/strict'
const source = resolve('previews/continuous-24h-2026-10-29/model-lifecycle')
const target = resolve('artifacts/continuous-24h-2026-10-29/model-lifecycle')
const hash = value => createHash('sha256').update(value).digest('hex')
const normalize = value => value.toString('utf8').replace(/\r\n/g, '\n').split('\n').map(line => line.trimEnd()).join('\n').trimEnd() + '\n'
const walk = dir => readdirSync(dir, { withFileTypes: true }).filter(item => !item.name.startsWith('.playwright-artifacts')).flatMap(item => item.isDirectory() ? walk(join(dir, item.name)) : [join(dir, item.name)])
assert.match(readFileSync(join(source, 'package-e2e.txt'), 'utf8'), /22 passed/)
assert.match(readFileSync(join(source, 'verify.txt'), 'utf8'), /775 passed/)
const receipt = JSON.parse(readFileSync(join(source, 'package-receipt.json'), 'utf8'))
for (const file of receipt.sourceFiles) assert.equal(hash(readFileSync(file.path)), file.sha256, file.path)
assert.ok(!existsSync(target), 'Choose a new archive rather than overwriting frozen evidence')
mkdirSync(target, { recursive: true })
const entries = []
const copy = (from, dest) => {
  const bytes = readFileSync(from), textual = ['.txt', '.md', '.json', '.mjs'].includes(extname(from))
  const result = textual ? Buffer.from(normalize(bytes)) : bytes
  const to = join(target, dest)
  mkdirSync(resolve(to, '..'), { recursive: true }); writeFileSync(to, result)
  entries.push({ path: dest.replaceAll('\\', '/'), bytes: result.length, sha256: hash(result), ...(textual ? { originalSha256: hash(bytes), textLfSha256: hash(result.toString('utf8').replace(/\r\n/g, '\n')) } : {}) })
}
for (const item of readdirSync(source, { withFileTypes: true })) {
  if (item.isFile() && ['.txt', '.json'].includes(extname(item.name))) copy(join(source, item.name), item.name)
}
copy(join(source, 'package-receipt.mjs'), 'package-receipt.mjs.txt')
for (const folder of ['old-package-red', 'old-package-confirmed-red', 'package-e2e']) {
  for (const path of walk(join(source, folder))) copy(path, join(folder, relative(join(source, folder), path)))
}
copyFileSync(join(source, 'raw-text-evidence.zip'), join(target, 'raw-text-evidence.zip'))
const raw = readFileSync(join(target, 'raw-text-evidence.zip'))
entries.push({ path: 'raw-text-evidence.zip', bytes: raw.length, sha256: hash(raw) })
writeFileSync(join(target, 'manifest.json'), JSON.stringify({ archivedAt: new Date().toISOString(), baseline: receipt.baseline, sourceFiles: receipt.sourceFiles, files: entries }, null, 2) + '\n')
for (const entry of entries) assert.equal(hash(readFileSync(join(target, entry.path))), entry.sha256)
console.log(JSON.stringify({ archivedFiles: entries.length, bytes: entries.reduce((sum, entry) => sum + entry.bytes, 0), mismatches: 0 }))
