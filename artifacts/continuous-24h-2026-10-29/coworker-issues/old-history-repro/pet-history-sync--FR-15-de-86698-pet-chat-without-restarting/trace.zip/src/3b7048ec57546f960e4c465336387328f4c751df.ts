import { expect, test } from '@playwright/test'
import { closeApp, configureTestModel, findMainPage, findPetPage, launchApp, startModelServer } from './helpers'

test('[FR-15] deleting the active history clears the open pet chat without restarting', async () => {
  const server = await startModelServer(), app = await launchApp()
  try {
    const main = await findMainPage(app), pet = await findPetPage(app)
    await configureTestModel(main, server.url)
    await main.getByTestId('nav-chat').click()
    await main.getByLabel('新建会话', { exact: true }).click()
    await main.getByTestId('chat-input').fill('这条历史删除后不应留在桌宠窗口')
    await main.getByTestId('chat-send').click()
    await expect(main.locator('.message-row.assistant').last()).toContainText('真实流式回复')
    await pet.locator('.pet-character').click({ button: 'right' })
    await pet.getByRole('button', { name: '打开对话', exact: true }).click()
    await expect(pet.locator('.pet-chat')).toContainText('这条历史删除后不应留在桌宠窗口')
    await main.getByTestId('nav-history').click()
    await main.getByTestId('clear-history').click()
    await main.getByRole('dialog').getByRole('button', { name: '按范围清除' }).click()
    await expect(main.getByTestId('history-item')).toHaveCount(0)
    await expect(pet.locator('.pet-chat')).not.toContainText('这条历史删除后不应留在桌宠窗口')
    await expect(pet.locator('.pet-chat')).not.toContainText('真实流式回复')
    await pet.screenshot({ path: test.info().outputPath('pet-history-cleared.png') })
  } finally { await closeApp(app); await server.close() }
})

test('[FR-03] tapping the pet keeps chat visibility and the menu explicitly opens and closes it', async () => {
  const app = await launchApp()
  try {
    await findMainPage(app)
    const pet = await findPetPage(app)
    await expect(pet.getByTestId('live2d-canvas')).toBeVisible()
    await pet.evaluate(() => window.murasame.pet.setChatOpen(false))
    await pet.locator('.pet-character').click()
    await expect(pet.locator('.pet-chat')).toHaveCount(0)
    await pet.locator('.pet-character').click({ button: 'right' })
    await pet.getByRole('button', { name: '打开对话', exact: true }).click()
    await expect(pet.locator('.pet-chat')).toBeVisible()
    await pet.locator('.pet-character').click()
    await expect(pet.locator('.pet-chat')).toBeVisible()
    await pet.locator('.pet-character').click({ button: 'right' })
    await pet.getByRole('button', { name: '收起对话', exact: true }).first().click()
    await expect(pet.locator('.pet-chat')).toHaveCount(0)
    await pet.screenshot({ path: test.info().outputPath('pet-menu-controls-chat.png') })
  } finally { await closeApp(app) }
})
