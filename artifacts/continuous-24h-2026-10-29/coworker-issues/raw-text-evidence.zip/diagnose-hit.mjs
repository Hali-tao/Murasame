import { _electron as electron } from '@playwright/test'
import { mkdtempSync, writeFileSync, rmSync } from 'node:fs'
import { resolve, join } from 'node:path'
const dir = resolve('previews/coworker-issues-2026-10-29')
const profile = mkdtempSync(resolve('previews/tmp/murasame-hit-'))
writeFileSync(join(profile, 'murasame.json'), JSON.stringify({ settings: { onboardingDone: true } }))
const app = await electron.launch({ executablePath: resolve('release/continuous-2026-10-29-model-status-sync-final/win-unpacked/Murasame.exe'), env: { ...process.env, MURASAME_USER_DATA: profile } })
const result = []
try {
  let pet
  for(let i=0;i<100;i++) { pet=app.windows().find(p=>p.url().includes('pet.html')); if(pet) break; await new Promise(r=>setTimeout(r,100)) }
  if(!pet) throw new Error('No pet')
  await app.evaluate(({ BrowserWindow }) => {
    globalThis.__hitCalls=[]
    const win=BrowserWindow.getAllWindows().find(w=>w.webContents.getURL().includes('pet.html'))
    const original=win.setIgnoreMouseEvents.bind(win)
    win.setIgnoreMouseEvents=(ignore,options)=> { globalThis.__hitCalls.push(ignore); original(ignore,options) }
  })
  await pet.waitForSelector('.live2d-pet-host[data-motion-group]')
  const samples=await pet.evaluate(async()=>{
    const canvas=document.querySelector('canvas'), rect=canvas.getBoundingClientRect()
    const bitmap=await createImageBitmap(canvas)
    const copy=new OffscreenCanvas(bitmap.width,bitmap.height), ctx=copy.getContext('2d');ctx.drawImage(bitmap,0,0)
    const pixels=ctx.getImageData(0,0,bitmap.width,bitmap.height).data
    const points=[]
    for(let row=1;row<10;row++) {
      const y=Math.floor(bitmap.height*row/10), xs=[]
      for(let x=0;x<bitmap.width;x++) if(pixels[(y*bitmap.width+x)*4+3]>200)xs.push(x)
      if(xs.length>5) for(const f of [.25,.5,.75]) {
        const x=xs[Math.floor((xs.length-1)*f)]
        points.push({row, x:rect.left+x/bitmap.width*rect.width, y:rect.top+y/bitmap.height*rect.height})
      }
    }
    return points
  })
  for(const point of samples) {
    await pet.mouse.move(1,1);await new Promise(r=>setTimeout(r,70))
    await pet.mouse.move(point.x,point.y);await new Promise(r=>setTimeout(r,70))
    const calls=await app.evaluate(()=>globalThis.__hitCalls)
    result.push({...point,ignore:calls.at(-1)})
  }
  await pet.screenshot({path:join(dir,'old-hit-diagnostic.png')})
  await pet.evaluate(()=>{
    window.__pointerEvents=[]
    for(const type of ['pointerdown','pointerup','pointercancel','pointermove']) window.addEventListener(type,event=>window.__pointerEvents.push({type, target:event.target.className, x:event.clientX,y:event.clientY,screenX:event.screenX,screenY:event.screenY,button:event.button}))
  })
  const point=samples.find(p=>p.row===7)
  await pet.mouse.move(point.x,point.y);await new Promise(r=>setTimeout(r,80));await pet.mouse.down();await pet.mouse.up();await new Promise(r=>setTimeout(r,200))
  const after=await pet.evaluate(()=>({events:window.__pointerEvents,motion:document.querySelector('.live2d-pet-host')?.dataset.motionGroup,chatOpen:!!document.querySelector('.pet-chat')}))
  writeFileSync(join(dir,'old-hit-diagnostic.json'),JSON.stringify({samples:result,opaqueIgnored:result.filter(p=>p.ignore).length,after},null,2))
  console.log(JSON.stringify(result))
} finally { await app.close();rmSync(profile,{recursive:true,force:true}) }
