import { defineConfig } from '@playwright/test'
export default defineConfig({ testDir: '.', testMatch: 'notification-diagnostic.spec.ts', workers: 1, reporter: [['list']], timeout: 60_000, use: { trace: 'retain-on-failure', screenshot: 'only-on-failure' } })
